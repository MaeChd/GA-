# 导入第三方库
from PIL import Image, ImageDraw
import numpy as np
import os
import random as r
import matplotlib.pyplot as plt
import minpy.numpy as mmp


# 关于图像颜色的类
class Color:
    """
    4个关于图像颜色的通道: R,G,B,A
    """

    def __init__(self):
        self.r = r.randint(0, 255)
        self.g = r.randint(0, 255)
        self.b = r.randint(0, 255)
        self.a = r.randint(95, 115)


def mutate_or_not(rate):
    '''
    生成随机数，判断是否需要变异
    '''
    return True if rate > r.uniform(0, 1) else False


def crossover_or_not(rate):
    """
    生成随机数，判断是否需要交换
    """
    return True if rate > r.uniform(0, 1) else False


# class三角形类
class Triangle:
    """
    attribute:
     三角形3个顶点->6个关于坐标的值 ：ax,ay,bx,by,cx,cy
     三角形颜色 color
     三角形合成图片 img_triangle
    method：
        三角形生成与绘制   create_a_triangle
        三角形产生变异     mutation_triangle

    """
    max_mutate_rate = 0.08
    mid_mutate_rate = 0.3
    min_mutate_rate = 0.8

    def __init__(self, size=(255, 255)):
        self.ax = r.randint(0, size[0])
        self.ay = r.randint(0, size[1])
        self.bx = r.randint(0, size[0])
        self.by = r.randint(0, size[1])
        self.cx = r.randint(0, size[0])
        self.cy = r.randint(0, size[1])
        self.color = Color()
        self.img_triangle = None

    def create_a_triangle(self, Size=(256, 256)):  # Size：每个通道为256*256的矩阵
        pts = [(self.ax, self.ay), (self.bx, self.by), (self.cx, self.cy)]  # 点坐标
        color = (self.color.r, self.color.g, self.color.b, self.color.a)  # 颜色的四个通道
        self.img_triangle = Image.new('RGBA', Size)  # 生成PIL.Image 对象实例
        draw = ImageDraw.Draw(self.img_triangle)  # 生成ImageDraw 对象实例
        draw.polygon(pts, fill=color)  # 调用polygon方法 绘图 , 传递点坐标，颜色参数
        return self.img_triangle

    def mutation_triangle(self, m_triangle):
        # 变异实际上是坐标点进行变化
        # 随机生成小数与变异率比较判断该坐标是否变异
        if mutate_or_not(self.max_mutate_rate):
            self.ax = r.randint(0, 255)
            self.ay = r.randint(0, 255)
        if mutate_or_not(self.mid_mutate_rate):
            self.ax = min(max(0, m_triangle.ax + r.randint(-15, 15)), 255)
            self.ay = min(max(0, m_triangle.ay + r.randint(-15, 15)), 255)
        if mutate_or_not(self.min_mutate_rate):
            self.ax = min(max(0, m_triangle.ax + r.randint(-3, 3)), 255)
            self.ay = min(max(0, m_triangle.ay + r.randint(-3, 3)), 255)

        if mutate_or_not(self.max_mutate_rate):
            self.bx = r.randint(0, 255)
            self.by = r.randint(0, 255)
        if mutate_or_not(self.mid_mutate_rate):
            self.bx = min(max(0, m_triangle.bx + r.randint(-15, 15)), 255)
            self.by = min(max(0, m_triangle.by + r.randint(-15, 15)), 255)
        if mutate_or_not(self.min_mutate_rate):
            self.bx = min(max(0, m_triangle.bx + r.randint(-3, 3)), 255)
            self.by = min(max(0, m_triangle.by + r.randint(-3, 3)), 255)

        if mutate_or_not(self.max_mutate_rate):
            self.cx = r.randint(0, 255)
            self.cy = r.randint(0, 255)
        if mutate_or_not(self.mid_mutate_rate):
            self.cx = min(max(0, m_triangle.cx + r.randint(-15, 15)), 255)
            self.cy = min(max(0, m_triangle.cy + r.randint(-15, 15)), 255)
        if mutate_or_not(self.min_mutate_rate):
            self.cx = min(max(0, m_triangle.cx + r.randint(-3, 3)), 255)
            self.cy = min(max(0, m_triangle.cy + r.randint(-3, 3)), 255)
        # color
        if mutate_or_not(self.max_mutate_rate):
            self.color.r = r.randint(0, 255)
        if mutate_or_not(self.mid_mutate_rate):
            self.color.r = min(max(0, m_triangle.color.r + r.randint(-30, 30)), 255)
        if mutate_or_not(self.min_mutate_rate):
            self.color.r = min(max(0, m_triangle.color.r + r.randint(-10, 10)), 255)

        if mutate_or_not(self.max_mutate_rate):
            self.color.g = r.randint(0, 255)
        if mutate_or_not(self.mid_mutate_rate):
            self.color.g = min(max(0, m_triangle.color.g + r.randint(-30, 30)), 255)
        if mutate_or_not(self.min_mutate_rate):
            self.color.g = min(max(0, m_triangle.color.g + r.randint(-10, 10)), 255)

        if mutate_or_not(self.max_mutate_rate):
            self.color.b = r.randint(0, 255)
        if mutate_or_not(self.mid_mutate_rate):
            self.color.b = min(max(0, m_triangle.color.b + r.randint(-30, 30)), 255)
        if mutate_or_not(self.min_mutate_rate):
            self.color.b = min(max(0, m_triangle.color.b + r.randint(-10, 10)), 255)
        # alpha
        if mutate_or_not(self.mid_mutate_rate):
            self.color.a = r.randint(95, 115)
        if mutate_or_not(self.mid_mutate_rate):
            self.color.a = min(max(0, m_triangle.color.a + r.randint(-30, 30)), 255)
        if mutate_or_not(self.min_mutate_rate):
            self.color.a = min(max(0, m_triangle.color.a + r.randint(-10, 10)), 255)


# class绘图类
class Image_Triangle:
    """
    attribute:
        triangles:具有TriangleNums个三角形的列表
        tri_img :由TriangleNums个三角形组合成的图片
        fitness : 个体适应度
    method:
    生成TriangleNums个三角形  create_triangles
    三角形整合成一张图    compoundImg
    图片的交叉    crossover
    图片的变异    mutation
    图片的适应度计算  compute_fitness
    图片保存   saveImg
    """
    mutate_rate = 0.01
    crossover_rate = 0

    # 初始化
    def __init__(self):
        self.triangles = []
        self.tri_img = None
        self.fitness = 0
        self.Fitness = 0

    # 生成TriangleNums个三角形
    def create_triangles(self, nums):
        for i in range(0, nums):
            triangleImg = Triangle()
            self.triangles.append(triangleImg)

    # 三角形整合成一张图
    def compoundImg(self, Size=(256, 256)):
        self.tri_img = Image.new('RGBA', Size)
        draw = ImageDraw.Draw(self.tri_img)
        draw.polygon([(0, 0), (0, 255), (255, 255), (255, 0)], fill=(255, 255, 255, 255))
        for triangle in self.triangles:
            self.tri_img = Image.alpha_composite(self.tri_img,
                                                 triangle.img_triangle or triangle.create_a_triangle())  # 三角形图片融合

    # 图片的交叉
    # 单点交叉
    def one_point_crossover(self, parent1, parent2, child, Pc):

        nums = len(parent1)
        point = r.randint(0, 256)
        if crossover_or_not(Pc):
            self.triangles.extend(parent1[:point])
            child.triangles.extend(parent2[:point])
            self.triangles.extend(parent2[point:])
            child.triangles.extend(parent1[point:])

    # 两点交叉
    def two_point_crossover(self, parent1, parent2, child, Pc):
        nums = len(parent1)
        point1, point2 = r.sample(range(256), 2)
        (point1, point2) = (point1, point2) if point1 < point2 else (point2, point1)
        if crossover_or_not(Pc) and crossover_or_not(Pc):
            self.triangles.extend(parent1[0:point1])
            self.triangles.extend(parent2[point1:point2])
            self.triangles.extend(parent1[point2:256])
            child.triangles.extend(parent2[0:point1])
            child.triangles.extend(parent1[point1:point2])
            child.triangles.extend(parent2[point2:256])

    # 均匀交叉
    def uniform_crossover(self, parent1, parent2, child):

        nums = len(parent1)
        for i in range(nums):
            if crossover_or_not(0.5):
                self.triangles.append(parent1[i])
                child.triangles.append(parent2[i])
            else:
                self.triangles.append(parent2[i])
                child.triangles.append(parent1[i])

    # 图片的变异
    # 最优个体变异
    def best_mutation(self, parent):
        for triangle in parent.triangles:
            if mutate_or_not(self.mutate_rate):
                a = Triangle()
                a.mutation_triangle(triangle)
                self.triangles.append(a)
            else:
                self.triangles.append(triangle)

    # 群体变异
    def Population_mutation(self, parent, Pm):
        for j in range(256):
            if mutate_or_not(Pm):
                a = Triangle()
                a.mutation_triangle(parent.triangles[j])
                self.triangles.append(a)
            else:
                self.triangles.append(parent.triangles[j])

    # 图片的适应度计算
    def compute_fitness(self, Img_array):  # 第二个参数是原图像四个通道矩阵
        self.tri_array = mmp.array(self.tri_img)  # 先将PIL图片对象转换成numpy数组,便于计算
        for i in range(3):  # 计算生成的图像RGB通道与目标图像RGB通道的离差平方和
            self.fitness += mmp.sum(mmp.square(self.tri_array[:, :, i] - Img_array[:, :, i]))[0]

    # 图片保存
    def saveImg(self, Path, i):  # 第2，3个参数分别是保存图像的路径，以及迭代次数
        self.tri_img.save(os.path.join(Path, "%d.png" % (i)))


# 进行遗传算法流程,同样定义一个类
class GA_Algorithm:
    """
    attribute:
    原图路径 imgPath
    图片保存路径 SavePath
    迭代单位次数 epochs
    一个个体中三角形个数 128/256 TriangleNums
    图像数据以矩阵形式存在 img

    method:
    交叉流程  crossover
    变异流程  mutation
    淘汰流程  Tournament_selection
    包含遗传算法整个流程  model_fit
    """
    mutate_rate = 0.01

    def __init__(self, size, imgPath, savePath, TriangleNums, epochs):
        self.size = size
        self.img = Image.open(imgPath).resize(self.size).convert('RGBA')  # 读取原图 得到PIL.Image.Image
        self.img_array = mmp.array(self.img)  # 转换成numpy矩阵
        self.TriangleNums = TriangleNums  # 一张图片中三角形个数
        self.savePath = savePath  # 保存拟合图片的路径
        self.epochs = epochs  # 迭代单位次数

    # ADA -- 自适应变异率和交叉率
    # fmax ——群体中最大的适应度值
    # favg ——每代群体的平均适应度值
    # ff ——要交叉的两个个体中较大的适应度值
    # f ——要变异的个体的适应度值
    # Pc1 = 0.9
    # Pc2 = 0.6，Pm1 = 0.1
    # Pm2 = 0.001
    # 自适应变异率
    def ada_mutation_rate(self, fm, fmax, favg):
        '''
        给予优秀个体低概率变异
        劣质个体高概率变异

        '''
        k2 = 0.5
        k4 = 0.5
        if fm < favg:
            Pm = k2 * (fm - fmax) / (favg - fmax) * favg / fm
            return Pm
        else:
            return k4

    #  自适应交叉率
    def ada_crossover_rate(self, fc, fmax, favg):
        k1 = 1.0
        k3 = 1.0
        if fc < favg:
            Pc = k1 * (fc - fmax) / (favg - fmax) * favg / fc
            return Pc
        else:
            return k3

    def Crossover(self, parents, fmax, favg):
        """
        交叉
        """
        l = 0
        childList = []
        for i in range(0, 20):  # 交叉
            j, k = r.sample(range(20), 2)
            ff = parents[j].fitness if parents[j].fitness < parents[k].fitness else parents[k].fitness
            Pc = self.ada_crossover_rate(ff, fmax, favg)
            childList.append(Image_Triangle())
            childList.append(Image_Triangle())
            # 选择下列交叉操作中的一个或者不选
            # 均匀交叉
            childList[l].uniform_crossover(parents[k].triangles, parents[j].triangles, childList[l + 1])
            # 单点交叉
            #             childList[l].one_point_crossover(parents[k].triangles,parents[j].triangles,childList[l+1],Pc)
            # 两点交叉
            #             childList[l].two_point_crossover(parents[k].triangles,parents[j].triangles,childList[l+1],Pc)
            childList[l].compoundImg()
            childList[l + 1].compoundImg()
            childList[l].compute_fitness(self.img_array)
            childList[l + 1].compute_fitness(self.img_array)
            l += 2
        return childList

    def Mutation(self, parent, fmax, favg):
        """
        整个变异流程：

        """
        childList = []
        # 群体变异
        #         j = 0
        #         for i in range(20):#变异
        #             f = parent[i].fitness
        #             Pm  = self.ada_mutation_rate(f, fmax, favg)
        #             childList.append(Image_Triangle())
        #             childList[j].Population_mutation(parent[i],Pm)
        #             childList[j].compoundImg()
        #             childList[j].compute_fitness(self.img_array)
        #             j+=1
        # 最优个体变异
        for i in range(20):
            childList.append(Image_Triangle())
            childList[i].best_mutation(parent)
            childList[i].compoundImg()
            childList[i].compute_fitness(self.img_array)
        return childList

    def Tournament_selection(self, parents):
        """
        锦标赛法选择

        """
        childList = []
        nums = len(parents)
        # 进行锦标赛选择 有放回抽样
        while len(childList) <= 20:
            i, j = r.sample(range(nums), 2)
            if parents[i].fitness > parents[j].fitness:
                childList.append(parents[j])
            else:
                childList.append(parents[i])
        return childList

    def sort_selection(self, parents):
        '''
        确定性选择
        '''
        parents.sort(key=lambda x: x.fitness, reverse=False)
        return parents[:20]

    # 绘制收敛曲线
    def Draw_convergence_curve(self, generation, generation_counts, fitness_3):
        # 每隔epochs代保存一次图片，输出适应度值，并绘制一次收敛曲线
        if generation_counts % self.epochs == 0:
            print(
                '{} Best Fitness rate: {}\n Average Fitness rate :{}\n worst Fitness rate:{}'.format(generation_counts,
                                                                                                     fitness_3[0][
                                                                                                         generation_counts],
                                                                                                     fitness_3[1][
                                                                                                         generation_counts],
                                                                                                     fitness_3[2][
                                                                                                         generation_counts]))
            if generation_counts % 1000 == 0:
                n = generation_counts - 980  # 让部分区域图像更清晰
                plt.rc('font', size=16)
                plt.plot(generation[n:], fitness_3[0][n:], 'r', label='best')  # 最好的个体的适应度
                plt.plot(generation[n:], fitness_3[1][n:], 'b', label='average')  # 中等的个体的适应度
                plt.plot(generation[n:], fitness_3[2][n:], 'g', label='worst')  # 最差的个体的适应度
                plt.xlabel(xlabel='generation')
                plt.ylabel(ylabel='fitness')
                plt.legend()
                plt.show()

            plt.rc('font', size=16)
            plt.plot(generation, fitness_3[0], 'r', label='best')  # 最好的个体的适应度
            plt.plot(generation, fitness_3[1], 'b', label='average')  # 中等的个体的适应度
            plt.plot(generation, fitness_3[2], 'g', label='worst')  # 最差的个体的适应度
            plt.xlabel(xlabel='generation')
            plt.ylabel(ylabel='fitness')
            plt.legend()
            plt.show()

    def model_fit(self):
        """
        遗传算法模型流程：
        首先生成初代个体
        选择最优初代个体作为双亲parent
        进入selection循环:
            交叉->变异->选择
            每epochs绘制收敛曲线
            满足终止条件退出循环
        """

        generation = []  # 种群代数，初始是第0代
        parents = []
        fitness_3 = [[], [], []]  # 每一代中最差，中等，最好的个体的适应度
        childList = []
        # 生成初代个体,随机产生40个个体
        for i in range(40):
            parents.append(Image_Triangle())  # 将Image_对象实例加入到种群列表中国
            parents[i].create_triangles(TriangleNums)  # 第i个个体生成TriangleNums个三角形
            parents[i].compoundImg()
            parents[i].compute_fitness(self.img_array)  # 将第i个个体 随机生成的多个三角形合成一个图像

        # 开始迭代
        for generation_counts in range(0, 30000):  # generation_counts迭代次数 初始为0
            # 锦标赛选择
            #             parents = self.Tournament_selection(parents)#选择20个个体组成种群
            #             parents.sort(key=lambda x: x.fitness, reverse=False)#升序排列
            # 确定性选择
            parents = self.sort_selection(parents)
            for i, j in [[0, 0], [1, 9], [2, 19]]:
                fitness_3[i].append(parents[j].fitness)
            parents_best = parents[0]
            parents_worst = parents[19]
            parents_avg = parents[9]
            generation.append(generation_counts)  # 种群迭代次数
            # 绘制收敛曲线
            self.Draw_convergence_curve(generation, generation_counts, fitness_3)
            # 选择操作
            fmax = parents_best.fitness
            favg = parents_avg.fitness
            # 新生成的个体所组成的种群列表
            childList_crossover = self.Crossover(parents, fmax, favg)  # 交叉
            #             childList_mutation = self.Mutation(parents,fmax,favg) #群体变异
            childList_mutation = self.Mutation(parents_best, fmax, favg)  # 最优个体变异
            parents.extend(childList_crossover)
            parents.extend(childList_mutation)
            del childList_mutation
            del childList_crossover
            if generation_counts % self.epochs == 0:
                parents_best.saveImg(self.savePath + str('\\best'), generation_counts)
                parents_worst.saveImg(self.savePath + str('\\worst'), generation_counts)


"""
global 参数
"""
# 原图路径
imgPath = r"../火狐浏览器图标.png"
# 图片保存路径
SavePath = r"../img"
# 迭代单位次数
epochs = 100
# 一个个体中三角形个数 128/256
TriangleNums = 256
# 图片通道矩阵大小
size = (256, 256)

if __name__ == '__main__':
    GA_Img = GA_Algorithm(size, imgPath, SavePath, TriangleNums, epochs)
    print('开始进行遗传算法')
    GA_Img.model_fit()






